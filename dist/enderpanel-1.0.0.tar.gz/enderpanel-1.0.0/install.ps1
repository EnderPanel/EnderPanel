Write-Host "=== MC Panel Installer ===" -ForegroundColor Cyan
Write-Host ""

if (-not (Get-Command python -ErrorAction SilentlyContinue)) {
    Write-Host "Python not found. Please install it from https://python.org" -ForegroundColor Red
    exit 1
}

if (-not (Get-Command node -ErrorAction SilentlyContinue)) {
    Write-Host "Node.js not found. Please install it from https://nodejs.org" -ForegroundColor Red
    exit 1
}

Write-Host "Checking Java installations..." -ForegroundColor Yellow

$java8 = "$env:ProgramFiles\Eclipse Adoptium\jre-8"
$java17 = "$env:ProgramFiles\Eclipse Adoptium\jre-17"
$java21 = "$env:ProgramFiles\Eclipse Adoptium\jre-21"

if (-not (Test-Path $java8) -and -not (Get-Command java -ErrorAction SilentlyContinue | Where-Object { $_.Source -like "*jre-8*" })) {
    Write-Host "Installing Java 8..." -ForegroundColor Yellow
    if (Get-Command winget -ErrorAction SilentlyContinue) {
        winget install EclipseAdoptium.Temurin.8.JRE
    } else {
        Write-Host "winget not found. Install Java 8 manually from: https://adoptium.net" -ForegroundColor Yellow
    }
} else {
    Write-Host "Java 8 found." -ForegroundColor Green
}

if (-not (Test-Path $java17) -and -not (Get-Command java -ErrorAction SilentlyContinue | Where-Object { $_.Source -like "*jre-17*" })) {
    Write-Host "Installing Java 17..." -ForegroundColor Yellow
    if (Get-Command winget -ErrorAction SilentlyContinue) {
        winget install EclipseAdoptium.Temurin.17.JRE
    } else {
        Write-Host "winget not found. Install Java 17 manually from: https://adoptium.net" -ForegroundColor Yellow
    }
} else {
    Write-Host "Java 17 found." -ForegroundColor Green
}

if (-not (Test-Path $java21) -and -not (Get-Command java -ErrorAction SilentlyContinue | Where-Object { $_.Source -like "*jre-21*" })) {
    Write-Host "Installing Java 21..." -ForegroundColor Yellow
    if (Get-Command winget -ErrorAction SilentlyContinue) {
        winget install EclipseAdoptium.Temurin.21.JRE
    } else {
        Write-Host "winget not found. Install Java 21 manually from: https://adoptium.net" -ForegroundColor Yellow
    }
} else {
    Write-Host "Java 21 found." -ForegroundColor Green
}

if (-not (Get-Command docker -ErrorAction SilentlyContinue)) {
    Write-Host "Docker not found. Installing..." -ForegroundColor Yellow

    if (Get-Command winget -ErrorAction SilentlyContinue) {
        Write-Host "Installing Docker Desktop via winget..." -ForegroundColor Yellow
        winget install Docker.DockerDesktop
        Write-Host "Docker Desktop installed. Please restart your computer and open Docker Desktop." -ForegroundColor Green
    } else {
        Write-Host "winget not found." -ForegroundColor Red
        Write-Host "Install Docker manually from: https://www.docker.com/products/docker-desktop/" -ForegroundColor Yellow
        Write-Host "Or install winget from: https://aka.ms/getwinget" -ForegroundColor Yellow
        exit 1
    }
} else {
    Write-Host "Docker found." -ForegroundColor Green
}

try {
    docker info 2>$null | Out-Null
} catch {
    Write-Host "Docker daemon is not running. Please start Docker Desktop and try again." -ForegroundColor Red
    exit 1
}

Write-Host ""
Write-Host "Installing backend dependencies..." -ForegroundColor Yellow
Set-Location backend
python -m pip install -r requirements.txt

Write-Host ""
Write-Host "Installing frontend dependencies..." -ForegroundColor Yellow
Set-Location ..\frontend
npm install

Write-Host ""
Write-Host "=== Installation Complete ===" -ForegroundColor Green
Write-Host ""
Write-Host "To start the panel:" -ForegroundColor Cyan
Write-Host ""
Write-Host "  cd frontend" -ForegroundColor White
Write-Host "  npm run dev" -ForegroundColor White
Write-Host ""
Write-Host "Then open http://localhost:3000" -ForegroundColor Cyan
